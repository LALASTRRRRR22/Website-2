<?php
/**
 * Общие вспомогательные функции для проекта бытовых услуг.
 *
 * Этот файл содержит функции для авторизации пользователя,
 * создания и поиска рабочих чатов, проверки откликов и других
 * часто используемых задач. Его следует подключать на страницах
 * вместо копирования одинакового кода. Все функции используют
 * переданный объект mysqli для работы с базой данных.
 */

// Предотвращаем прямой вызов файла через браузер
if (basename(__FILE__) === basename($_SERVER['PHP_SELF'])) {
    exit;
}

/**
 * Получить ID текущего пользователя из сессии или базы.
 *
 * Функция пытается определить идентификатор пользователя,
 * используя различные поля, которые могли быть сохранены в сессии.
 * Возвращает 0, если пользователь не авторизован.
 *
 * @param mysqli $conn Соединение с базой
 * @return int ID пользователя или 0
 */
function getCurrentUserId($conn)
{
    $userId = 0;
    $login = '';

    // Попытка получить ID из разных полей сессии
    if (!empty($_SESSION['user_id'])) {
        $userId = (int)$_SESSION['user_id'];
    }
    if ($userId <= 0 && !empty($_SESSION['Id_U'])) {
        $userId = (int)$_SESSION['Id_U'];
    }
    if ($userId <= 0 && !empty($_SESSION['user']) && is_array($_SESSION['user'])) {
        if (!empty($_SESSION['user']['Id_U'])) {
            $userId = (int)$_SESSION['user']['Id_U'];
        } elseif (!empty($_SESSION['user']['id'])) {
            $userId = (int)$_SESSION['user']['id'];
        }
    }

    // Логин может пригодиться для поиска ID
    if (!empty($_SESSION['login'])) {
        $login = trim((string)$_SESSION['login']);
    }
    if ($login === '' && !empty($_SESSION['username'])) {
        $login = trim((string)$_SESSION['username']);
    }

    // Если ID не найден, пробуем найти в базе по логину
    if ($userId <= 0 && $login !== '') {
        $stmt = $conn->prepare('SELECT Id_U FROM Users WHERE login = ? LIMIT 1');
        if ($stmt) {
            $stmt->bind_param('s', $login);
            $stmt->execute();
            $stmt->bind_result($foundId);
            if ($stmt->fetch()) {
                $userId = (int)$foundId;
            }
            $stmt->close();
        }
    }

    return $userId;
}

/**
 * Проверить, откликался ли пользователь на конкретный заказ.
 *
 * @param mysqli $conn Соединение с базой
 * @param int $orderId ID заказа
 * @param int $userId ID пользователя
 * @return bool true если отклик уже существует
 */
function hasResponded($conn, $orderId, $userId)
{
    $exists = false;
    $stmt = $conn->prepare('SELECT id FROM responses WHERE order_id = ? AND user_id = ? LIMIT 1');
    if ($stmt) {
        $stmt->bind_param('ii', $orderId, $userId);
        $stmt->execute();
        $stmt->bind_result($responseId);
        if ($stmt->fetch()) {
            $exists = true;
        }
        $stmt->close();
    }
    return $exists;
}

/**
 * Создать или получить чат между заказчиком и исполнителем по заказу.
 *
 * Если чат уже существует (комбинация order_id+client_id+worker_id уникальна),
 * функция возвращает его ID. В противном случае создаётся новая запись.
 *
 * @param mysqli $conn Соединение с базой
 * @param int $orderId ID заказа
 * @param int $clientId ID заказчика
 * @param int $workerId ID исполнителя
 * @return int ID чата
 */
function getOrCreateChat($conn, $orderId, $clientId, $workerId)
{
    $chatId = 0;
    // Сначала пытаемся найти существующий чат
    $stmt = $conn->prepare('SELECT id FROM order_chats WHERE order_id = ? AND client_id = ? AND worker_id = ? LIMIT 1');
    if ($stmt) {
        $stmt->bind_param('iii', $orderId, $clientId, $workerId);
        $stmt->execute();
        $stmt->bind_result($foundId);
        if ($stmt->fetch()) {
            $chatId = (int)$foundId;
        }
        $stmt->close();
    }
    // Если не нашли, создаём
    if ($chatId <= 0) {
        $stmt = $conn->prepare('INSERT INTO order_chats (order_id, client_id, worker_id) VALUES (?, ?, ?)');
        if ($stmt) {
            $stmt->bind_param('iii', $orderId, $clientId, $workerId);
            if ($stmt->execute()) {
                $chatId = (int)$conn->insert_id;
            }
            $stmt->close();
        }
    }
    return $chatId;
}

/**
 * Проверить, может ли текущий пользователь откликнуться на заказ.
 * Запрещает откликаться на свой заказ или повторно.
 *
 * @param mysqli $conn Соединение с базой
 * @param int $orderId ID заказа
 * @param int $userId ID пользователя
 * @return bool true если можно откликнуться
 */
function canRespondToOrder($conn, $orderId, $userId)
{
    // Проверяем владельца заказа
    $stmt = $conn->prepare('SELECT client_id FROM orders WHERE id = ? LIMIT 1');
    if ($stmt) {
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $stmt->bind_result($clientId);
        if ($stmt->fetch()) {
            // Нельзя откликаться на свой заказ
            if ((int)$clientId === $userId) {
                $stmt->close();
                return false;
            }
        }
        $stmt->close();
    }
    // Проверяем, что отклик уже не был отправлен
    return !hasResponded($conn, $orderId, $userId);
}

/**
 * Безопасный вывод для HTML. Экранирует специальные символы, чтобы предотвратить XSS.
 *
 * @param mixed $value Значение для вывода
 * @return string
 */
function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * Перенаправить пользователя на другую страницу.
 * Завершает выполнение скрипта.
 *
 * @param string $url URL перенаправления
 */
function redirect($url)
{
    header('Location: ' . $url);
    exit;
}