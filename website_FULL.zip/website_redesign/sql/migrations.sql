-- SQL миграции для обновления структуры базы данных проекта бытовых услуг
-- Этот файл содержит изменения, которые нужно применить к существующей базе данных
-- чтобы добавить новые поля и таблицы. Используйте его, если вы обновляете
-- старую версию проекта и не хотите импортировать test_bd.sql заново.

-- Добавляем новые поля в таблицу orders, если они ещё не существуют
ALTER TABLE `orders`
    ADD COLUMN `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `client_comment`,
    ADD COLUMN `city` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `category`,
    ADD COLUMN `urgency` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL AFTER `city`,
    ADD COLUMN `selected_performer_id` int(10) UNSIGNED DEFAULT NULL AFTER `urgency`;

-- Добавляем поля в responses: предложенная цена и статус отклика
ALTER TABLE `responses`
    ADD COLUMN `proposed_price` decimal(10,2) DEFAULT NULL AFTER `comment`,
    ADD COLUMN `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' AFTER `proposed_price`;

-- Добавляем поля reviewer_id и target_user_id в таблицу reviews
ALTER TABLE `reviews`
    ADD COLUMN `reviewer_id` int(10) UNSIGNED DEFAULT NULL AFTER `order_id`,
    ADD COLUMN `target_user_id` int(10) UNSIGNED DEFAULT NULL AFTER `reviewer_id`;

-- Создаём таблицу уведомлений
CREATE TABLE IF NOT EXISTS `notifications` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` int(10) NOT NULL,
    `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
    `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
    `text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `related_order_id` bigint(20) UNSIGNED DEFAULT NULL,
    `related_chat_id` bigint(20) UNSIGNED DEFAULT NULL,
    `is_read` tinyint(1) NOT NULL DEFAULT '0',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_notifications_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Создаём таблицу избранных заказов
CREATE TABLE IF NOT EXISTS `favorites` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` int(10) NOT NULL,
    `order_id` bigint(20) UNSIGNED NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uniq_user_order` (`user_id`,`order_id`),
    KEY `idx_fav_user` (`user_id`),
    KEY `idx_fav_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Создаём таблицу жалоб
CREATE TABLE IF NOT EXISTS `reports` (
    `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    `reporter_id` int(10) NOT NULL,
    `target_user_id` int(10) DEFAULT NULL,
    `order_id` bigint(20) UNSIGNED DEFAULT NULL,
    `message_id` bigint(20) UNSIGNED DEFAULT NULL,
    `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
    `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_reports_reporter` (`reporter_id`),
    KEY `idx_reports_order` (`order_id`),
    KEY `idx_reports_message` (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;