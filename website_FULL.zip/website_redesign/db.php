<?php
$DB_HOST = '127.0.0.1';
$DB_NAME = 'test_bd';
$DB_USER = 'root';
$DB_PASS = '';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    die('Ошибка подключения к БД: ' . $conn->connect_error);
}

$conn->set_charset('utf8mb4');